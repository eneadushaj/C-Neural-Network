// AI Checkers.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <iostream>
#include <iomanip>
#include <fstream>
#include <windows.h>
#include <vector>
using namespace std;

int blkb_whtt = 15;
int redb_yelt = 206;
int yelb_blut = 233;
int cynb_blut = 185;
int whtb_blkt = 240;
const double bias_input = -1.0;

HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

void bw()
{
	SetConsoleTextAttribute(hConsole, blkb_whtt);
}
void wb()
{
	SetConsoleTextAttribute(hConsole, whtb_blkt);
}
void ry()
{
	SetConsoleTextAttribute(hConsole, redb_yelt);
}
void yb()
{
	SetConsoleTextAttribute(hConsole, yelb_blut);
}
void cb()
{
	SetConsoleTextAttribute(hConsole, cynb_blut);
}


struct example
{
	vector<double> attributes;
	vector<double> output;
};

example* newexample(vector<double> attributes, vector<double> output)
{
	example* temp = new example;
	temp->attributes = attributes;
	temp->output = output;
	return temp;
}

struct examples
{
	int Ne; // Number of examples
	int Ni; // Number of input attributes
	int No; // Number of output values
	vector<example*> examples;
};

examples* newexamples()
{
	examples* temp = new examples;
	return temp;
}

struct Node
{
	vector<double> input_weights;
	vector<double> input_activations;
	vector<double> output_weights;
	double delta_j, delta_i;
	double in_j, in_i;
	double activation_value;
	double bias_weight;
	double bias_term = bias_input;
};

Node* newNode()
{
	Node* temp = new Node;
	return temp;
}


double g(double x)
{
	return (1 / (1 + exp(-x)));
}

double g_prime(double x)
{
	return (g(x) * (1 - g(x)));
}


struct NN
{
	int Ni;
	int Nh;
	int No;
	vector<Node*> input_layer;
	vector<Node*> hidden_layer;
	vector<Node*> output_layer;
	vector<vector<Node*>> layers = { input_layer , hidden_layer , output_layer };

	void reset_layers()
	{
		layers = { input_layer , hidden_layer , output_layer };
	}
};

NN* newNN()
{
	NN* temp = new NN;
	return temp;
}

int pos(int i, int j, int Ni)
{
	return i * Ni + j;
}

string get_file_path()
{
	char path[1000];
	cin.getline(path, sizeof(path));

	while (cin.fail())
	{
		cin.clear();
		cin.ignore(256, '\n');
		cout << "   Please retry entering a valid file path : ";
		cin >> path;
	}
	return path;
}

void print_examples(examples* examples)
{
	for (int i = 0; i < examples->examples.size(); i++)
	{
		cout << "Example " << i << " : " << endl;
		cout << endl << "Inputs: " << endl;
		for (int j = 0; j < examples->Ni; j++)
		{
			cout << setprecision(3) << fixed << examples->examples[i]->attributes[j] << " ";
		}

		cout << defaultfloat;

		cout << endl << "Output: " << endl;
		for (int j = 0; j < examples->No; j++)
		{
			cout << examples->examples[i]->output[j] << " ";
		}
		// Newline for new row
		cout << endl;
	}
}

void print_example(example* example)
{
	cout << endl << "Inputs: " << endl;
	for (int j = 0; j < example->attributes.size(); j++)
	{
		cout << setprecision(3) << fixed << example->attributes[j] << " ";
	}

	cout << defaultfloat;

	cout << endl << "Output: " << endl;
	for (int j = 0; j < example->output.size(); j++)
	{
		cout << example->output[j] << " ";
	}
	// Newline for new row
	cout << endl;

}


examples* read_example_file(examples* examples_master)
{
	string path;

	path = get_file_path();

	fstream inFileStr(path, ios::in);
	if (inFileStr.fail()) {
		cerr << "Unable to open " << path << endl;
		exit(-1);
	}

	int Ne = 0; // number of examples
	int Ni = 0; // number of input attributes
	int No = 0; // number of outputs
	int value; // the current value being looked at in the file
	int i = 0; // iterator for while loop
	while (inFileStr >> value)
	{
		// Look at the first 3 values of the file to get Ne, Ni, and No respectively
		if (i == 0)
		{
			Ne = value;

		}
		else if (i == 1)
		{
			Ni = value;

		}
		else if (i == 2)
		{
			No = value;

		}
		else
		{
			break;
		}

		i++;

	}

	//allocate the input array
	double* input;
	input = new double[Ne * Ni];

	//allocate the input array
	double* output;
	output = new double[Ne * No];

	int j;
	int width = Ni + No;
	int current_example;

	fstream inFileString(path, ios::in);
	if (inFileString.fail()) {
		cerr << "Unable to open " << path << endl;
		exit(-1);
	}

	i = 0;
	double num = 0.0;
	while (inFileString >> num)
	{
		if (i > 2)
		{
			j = i - 3;

			current_example = (j - j % width) / width;

			if (j % width < Ni)
			{
				input[pos(current_example, j % width, Ni)] = num;
			}
			else if (j % width >= Ni)
			{
				output[pos(current_example, j % width - Ni, No)] = num;
			}
		}
		i++;

	}

	for (int i = 0; i < Ne; i++)
	{
		vector<double> attributes;
		vector<double> output_activation;
		for (int j = 0; j < Ni; j++)
		{
			attributes.push_back(input[pos(i, j, Ni)]);
		}
		for (int j = 0; j < No; j++)
		{
			output_activation.push_back(output[pos(i, j, No)]);
		}


		examples_master->examples.push_back(newexample(attributes, output_activation));
	}

	examples_master->Ne = Ne;
	examples_master->Ni = Ni;
	examples_master->No = No;

	//deallocate the input and output array
	delete[]input;
	delete[]output;

	return examples_master;

}


void print_nn(NN* nn)
{
	cout << "------------------------------------------------------------------------------------------" << endl;
	cout << setprecision(3) << fixed;
	cout << endl << "Hidden Layer Weights:" << endl << endl;
	for (int i = 0; i < nn->Nh; i++)
	{
		cout << "Hidden Layer Node # " << i << " : " << endl;
		for (int j = 0; j < nn->Ni + 1; j++)
		{
			if (j == 0)
			{
				cout << "Layer Weights: ";
				cout << nn->hidden_layer[i]->input_weights[j] << " ";
			}
			else
			{
				cout << nn->hidden_layer[i]->input_weights[j] << " ";
			}
		}

		// Newline for new row

		cout << endl;
	}


	cout << endl << "Output Layer Weights:" << endl << endl;
	for (int i = 0; i < nn->No; i++)
	{
		cout << "Output Layer Node # " << i << " : " << endl;
		for (int j = 0; j < nn->Nh + 1; j++)
		{
			if (j == 0)
			{
				cout << "Layer Weights: ";
				cout << nn->output_layer[i]->input_weights[j] << " ";
			}
			else
			{
				cout << nn->output_layer[i]->input_weights[j] << " ";
			}
		}

		// Newline for new row

		cout << endl;
	}

	cout << endl << "-------------------------------------------------------------------------------------------------------------" << endl;
	cout << endl;
	cout << defaultfloat;
}






NN* read_nn_file(NN* nn)
{
	string path;

	cout << "Please enter a file path to a neural network file that you would like to train (Separate folders with either /, \\, or \\\\ ) : ";
	path = get_file_path();

	fstream inFileStr(path, ios::in);
	if (inFileStr.fail()) {
		cerr << "Unable to open " << path << endl;
		exit(-1);
	}

	int Ni = 0; // number of input weights for each hidden layer node
	int Nh = 0; // number of hidden layers
	int No = 0; // number of output layers
	int value; // the current value being looked at in the file
	int i = 0; // iterator for while loop
	while (inFileStr >> value)
	{
		// Look at the first 3 values of the file to get Ne, Ni, and No respectively
		if (i == 0)
		{
			Ni = value;
		}
		else if (i == 1)
		{
			Nh = value;

		}
		else if (i == 2)
		{
			No = value;
		}
		else
		{
			break;
		}

		i++;

	}

	// Make Ne, Ni, and No constant values to make arrays out of them

	int input_width = Ni + 1; // Add space for bias weight
	int hidden_layer_width = Nh + 1; // Add space for bias weight

	//allocate the input array
	double* hidden_weights;
	hidden_weights = new double[Nh * input_width];

	//allocate the input array
	double* output_weights;
	output_weights = new double[No * hidden_layer_width];

	fstream inFileString(path, ios::in);
	if (inFileString.fail()) {
		cerr << "Unable to open " << path << endl;
		exit(-1);
	}

	int current_node;
	i = 0;
	int j;
	double num = 0.0;
	while (inFileString >> num)
	{
		if (i > 2) // skip the first 3 numbers in the file that specify the layer sizes
		{
			j = i - 3; // shift the index to start at 0 instead of 3

			if (j < input_width * Nh)
			{
				current_node = (j - j % input_width) / input_width;
				hidden_weights[pos(current_node, j % input_width, input_width)] = num;
			}
			else if (j >= Nh * input_width)
			{
				j -= input_width * Nh;
				current_node = (j - j % hidden_layer_width) / hidden_layer_width;
				output_weights[pos(current_node, j % hidden_layer_width, hidden_layer_width)] = num;
			}
		}

		i++;

	}

	// Fill out the initial neural network, initial_nn

	nn->Ni = Ni;
	nn->Nh = Nh;
	nn->No = No;

	// initialize input weights for hidden and output layers
	// intiialize bias weights

	for (int i = 0; i < nn->Nh; i++)
	{
		nn->hidden_layer.push_back(newNode());
		for (int j = 0; j < nn->Ni + 1; j++)
		{
			nn->hidden_layer.back()->input_weights.push_back(hidden_weights[pos(i, j, input_width)]);
		}
	}

	for (int i = 0; i < nn->No; i++)
	{
		nn->output_layer.push_back(newNode());
		for (int j = 0; j < nn->Nh + 1; j++)
		{
			nn->output_layer.back()->input_weights.push_back(output_weights[pos(i, j, hidden_layer_width)]);
		}
	}

	for (int i = 0; i < nn->Nh; i++)
	{
		for (int j = 0; j < nn->hidden_layer.front()->input_weights.size(); j++)
		{
			nn->hidden_layer[i]->input_activations.push_back(0);
		}
	}

	for (int i = 0; i < nn->No; i++)
	{
		for (int j = 0; j < nn->output_layer.front()->input_weights.size(); j++)
		{
			nn->output_layer[i]->input_activations.push_back(0);
		}
	}

	//Print the neural Network

	cout << endl;
	cb();
	cout << "The neural network you have chosen has the following features: ";
	bw();
	cout << endl;

	print_nn(nn);

	cout << defaultfloat;

	//deallocate the input and output array
	delete[]hidden_weights;
	delete[]output_weights;

	return nn;
}


NN* back_propagation_learning(NN* nn, examples* examples_master, int epochs, double alpha)
{

	int iteration = 0;
	nn->reset_layers();

	for (int i = 0; i < nn->Ni; i++) //for each node in the input layer
	{
		nn->input_layer.push_back(newNode());
	}

	nn->reset_layers();

	cout << endl << endl;
	while (iteration < epochs)
	{
		if (iteration % 20 == 0)
		{
			cout << "Training Neural Network... Currently on epoch " << iteration << "..." << endl;
		}
		for (int q = 0; q < examples_master->examples.size(); q++)
		{
			for (int i = 0; i < nn->Ni; i++) //for each node in the input layer
			{
				nn->input_layer[i]->activation_value = examples_master->examples[q]->attributes[i];   // activation of each node is just the example value
			}
			nn->reset_layers();

			// Fill in the input activation values for each node in the hidden layer
			for (int i = 0; i < nn->Nh; i++)
			{
				for (int j = 0; j < nn->hidden_layer.front()->input_weights.size(); j++)
				{
					if (j == 0)
					{
						nn->hidden_layer[i]->input_activations[j] = bias_input;
					}
					else
					{
						nn->hidden_layer[i]->input_activations[j] = nn->input_layer[j - 1]->activation_value;
					}
				}
			}

			nn->reset_layers();
			for (int l = 1; l < nn->layers.size(); l++) // for each layer l
			{
				for (int j = 0; j < nn->layers[l].size(); j++) // for each node j in layer l
				{
					double in_j = 0;
					for (int k = 0; k < nn->layers[l - 1].size() + 1; k++) // for each node in previous layer (plus 1 for bias weight)
					{

						if (k == 0)
						{
							in_j += nn->layers[l][j]->input_weights[k] * bias_input;
						}
						else
						{
							in_j += ((nn->layers[l - 1])[k - 1]->activation_value) * ((nn->layers[l])[j]->input_weights[k]);  // input to node j, in_j = sum of the activation of the previous node times its respective weight
						}

						//activation of the curent node, a_j = g(in_j), where g is sigmoid
					}
					nn->layers[l][j]->in_j = in_j;
					nn->layers[l][j]->activation_value = g(in_j);
					nn->reset_layers();

				}
				nn->reset_layers();
			}
			nn->reset_layers();

			for (int j = 0; j < nn->layers.back().size(); j++) //each node j in the output layer
			{
				nn->reset_layers();
				double delta_j, in_j, y_j, a_j;
				in_j = nn->layers.back()[j]->in_j;
				a_j = nn->layers.back()[j]->activation_value;
				y_j = examples_master->examples[q]->output[j];
				delta_j = g_prime(in_j) * (y_j - a_j); //delta_j = g'(in_j) * (y_j - a_j) where y_j is the desired output of the jth utput node, and aj is the activation of the jth output node
				nn->layers.back()[j]->delta_j = delta_j;
				nn->reset_layers();
			}
			nn->reset_layers();

			int l = 1;
			for (int i = 0; i < nn->layers[l].size(); i++)//for each node i in layer l
			{
				double delta_i, in_i;
				in_i = nn->layers[l][i]->in_j; // potentially wrong
				double sum = 0;
				for (int j = 0; j < nn->layers[l + 1].size(); j++) //for each node j in layer l+1
				{
					sum += nn->layers[l + 1][j]->input_weights[i + 1] * nn->layers[l + 1][j]->delta_j; // + nn->layers[l + 1][j]->bias_weight * nn->layers[l + 1][j]->delta_j
					nn->reset_layers();
				}
				delta_i = g_prime(in_i) * sum; //delta_i = g'(in_i)*sum through the nodes at level l+1 of (weight of the ith node at level l to the jth node at level l+1)*(delta_j, or the delta of the jth node at level l+1)
				nn->layers[l][i]->delta_j = delta_i;
				nn->reset_layers();
			}
			nn->reset_layers();


			for (int l = 1; l < nn->layers.size(); l++)
			{
				for (int i = 0; i < nn->layers[l].size(); i++)
				{
					for (int k = 0; k < nn->layers[l - 1].size() + 1; k++)
					{
						if (k == 0)
						{
							nn->layers[l][i]->input_activations[k] = bias_input;
							nn->reset_layers();
						}
						else
						{
							nn->layers[l][i]->input_activations[k] = nn->layers[l - 1][k - 1]->activation_value;
							nn->reset_layers();
						}
					}
					nn->reset_layers();
				}
				nn->reset_layers();
			}
			nn->reset_layers();

			//for each weight wi,j in network (for every weight at all layers. i refers to nodes at one layer, j refers to nodes at next layer. For bias weights, i = 0 and ai = -1
				//wi,j = wi,j + alpha * a_i * delta_j

			for (int l = 1; l < nn->layers.size(); l++)
			{
				for (int j = 0; j < nn->layers[l].size(); j++)
				{
					for (int k = 0; k < nn->layers[l][j]->input_weights.size(); k++)
					{
						double w_ij = nn->layers[l][j]->input_weights[k];
						double ai = nn->layers[l][j]->input_activations[k];
						double delta_j = nn->layers[l][j]->delta_j;
						w_ij = w_ij + alpha * ai * delta_j;
						nn->layers[l][j]->input_weights[k] = w_ij;
						nn->reset_layers();

					}
				
				}
				nn->reset_layers();
			}
			nn->reset_layers();
		}
		nn->reset_layers();
		iteration++;
	}


	cout << endl << "Training Complete!" << endl << endl;
	nn->reset_layers();

	cout << endl;
	cb();
	cout << "Trained Neural Net: ";
	bw();
	cout << endl;
	print_nn(nn); // Print the new neural network
	cout << endl;
	return nn;

}

double adjust(double x)
{
	if (x >= .5)
	{
		return 1;
	}
	else if (x < 0.5)
	{
		return 0;
	}
}

vector<vector<double>> forward_propagation(NN* nn, examples* test_set)
{

	vector<vector<double>> output;
	nn->reset_layers();



	for (int q = 0; q < test_set->examples.size(); q++)
	{

		for (int i = 0; i < nn->Ni; i++) //for each node in the input layer
		{
			nn->input_layer[i]->activation_value = test_set->examples[q]->attributes[i];   // activation of each node is just the example value

		}

		nn->reset_layers();

		// Fill in the input activation values for each node in the hidden layer
		for (int i = 0; i < nn->Nh; i++)
		{
			for (int j = 0; j < nn->hidden_layer.front()->input_weights.size(); j++)
			{
				if (j == 0)
				{
					nn->hidden_layer[i]->input_activations[j] = bias_input;
				}
				else
				{
					nn->hidden_layer[i]->input_activations[j] = nn->input_layer[j - 1]->activation_value;
				}
			}
		}

		for (int l = 1; l < nn->layers.size(); l++) // for each layer l
		{
			for (int j = 0; j < nn->layers[l].size(); j++) // for each node j in layer l
			{
				double in_j = 0;
				for (int k = 0; k < nn->layers[l - 1].size() + 1; k++) // for each node in previous layer (plus 1 for bias weight)
				{

					if (k == 0)
					{
						in_j += nn->layers[l][j]->input_weights[k] * bias_input;
					}
					else
					{
						in_j += ((nn->layers[l - 1])[k - 1]->activation_value) * ((nn->layers[l])[j]->input_weights[k]);  // input to node j, in_j = sum of the activation of the previous node times its respective weight
					}

					//activation of the curent node, a_j = g(in_j), where g is sigmoid
				}
				((nn->layers[l])[j]->in_j) = in_j;
				((nn->layers[l])[j]->activation_value) = g(in_j);
				nn->reset_layers();
			}
			nn->reset_layers();
		}
		nn->reset_layers();

		vector<double> temp;
		for (int i = 0; i < nn->No; i++)
		{
			temp.push_back(adjust(nn->output_layer[i]->activation_value));
		}

		output.push_back(temp);

	}

	nn->reset_layers();
	return output;
}



int main()
{
	bw();
	int epochs = 0;
	double learning_rate = 0;

	examples* training_set, * test_set;
	training_set = newexamples();
	test_set = newexamples();

	NN* initial_nn = newNN();

	// C:\Users\enead\Downloads\cardio\cardio_short.train
	// C:\Users\enead\Downloads\cardio\cardio2.init
	// C:\Users\enead\Downloads\cardio\cardio_short.test

	// C:\\Users\\enead\\Desktop\\Enea Dushaj\\School\\Artificial Intelligence\\Project 2\\heart_disease.train.txt
	// C:\Users\enead\Desktop\Enea Dushaj\School\Artificial Intelligence\Project 2\heart_disease.init.txt
	// C:\Users\enead\Desktop\Enea Dushaj\School\Artificial Intelligence\Project 2\heart_disease.test.txt

		//     C:\Users\enead\Desktop\Enea Dushaj\School\Artificial Intelligence\Project 2\iris.init
	//path = "C:\\Users\\enead\\Desktop\\Enea Dushaj\\School\\Artificial Intelligence\\Project 2\\Initial WDBC Neural Network.txt";
	//path = "C:\\Users\\enead\\Desktop\\Enea Dushaj\\School\\Artificial Intelligence\\Project 2\\Grades Initial Neural Network.txt";
	initial_nn = read_nn_file(initial_nn);

	//     C:\Users\enead\Desktop\Enea Dushaj\School\Artificial Intelligence\Project 2\iris.train
	//string path = "C:\\Users\\enead\\Desktop\\Enea Dushaj\\School\\Artificial Intelligence\\Project 2\\WDBCtrainingset.txt";
	//string path = "C:\\Users\\enead\\Desktop\\Enea Dushaj\\School\\Artificial Intelligence\\Project 2\\Grades Training Set.txt";
	cout << "Please enter a file path to a training data set text file that you would like to train your neural network with (Separate folders with either /, \\, or \\\\ ) : ";
	training_set = read_example_file(training_set);

	//     C:\Users\enead\Desktop\Enea Dushaj\School\Artificial Intelligence\Project 2\iris.test
	//path = "C:\\Users\\enead\\Desktop\\Enea Dushaj\\School\\Artificial Intelligence\\Project 2\\WDBCtestset.txt";
	//path = "C:\\Users\\enead\\Desktop\\Enea Dushaj\\School\\Artificial Intelligence\\Project 2\\Grades Test Set.txt";
	cout << endl << "Please enter a file path to a test data set text file that you would like to test your neural network with (Separate folders with either /, \\, or \\\\ ) : ";
	test_set = read_example_file(test_set);


	cout << endl << "Please enter the number of epochs you would like to train your neural network for (positive integer value): ";
	cin >> epochs;

	while (epochs < 1 || cin.fail())
	{
		cin.clear();
		cin.ignore(256, '\n');
		cout << "Please enter a valid number for the amount of epochs you would like to train your neural network for (positive integer value >= 1):  ";
		cin >> epochs;
	}

	epochs = static_cast<double>(epochs);



	cout << endl << "Please enter the learning rate you would like to train your neural network with (number between 0.0 and 1.0): ";
	cin >> learning_rate;

	while (((learning_rate > 1) || (learning_rate < 0)) || cin.fail())
	{
		cin.clear();
		cin.ignore(256, '\n');
		cout << "Please enter a valid learning rate for training your neural network for (number between 0.0 and 1.0):  ";
		cin >> learning_rate;
	}


	cout << endl << "Please enter the name of the text file representing the trained neural network that you would like to output to the current working directory (add .txt as an extension if you wish): ";
	string nn_file_name;
	cin >> nn_file_name;

	cout << endl << "Please enter the name of the text file representing the results of the system acting on the test set that you would like to output to the current working directory (add .txt as an extension if you wish): ";
	string res_file_name;
	cin >> res_file_name;

	NN* trained_nn = back_propagation_learning(initial_nn, training_set, epochs, learning_rate);

	vector<vector<double>> output;
	output = forward_propagation(trained_nn, test_set);

	yb();
	cout << "Predicted Output of Test Set: ";
	bw();
	cout << endl;
	for (int q = 0; q < output.size(); q++)
	{
		cout << "Example " << q << " : ";
		for (int i = 0; i < output[q].size(); i++)
		{
			cout << output[q][i] << " ";
		}
		cout << endl;
	}

	vector<double> A, B, C, D;
	vector<double> Overall_accuracy, Precision, Recall, F1;

	for (int i = 0; i < output.front().size(); i++)
	{
		A.push_back(0);
		B.push_back(0);
		C.push_back(0);
		D.push_back(0);
		Overall_accuracy.push_back(0);
		Precision.push_back(0);
		Recall.push_back(0);
		F1.push_back(0);
	}




	for (int q = 0; q < output.size(); q++) // for each example
	{
		for (int i = 0; i < output[q].size(); i++) // for each output of each example
		{

			double expected = test_set->examples[q]->output[i];
			double predicted = output[q][i];

			if (predicted == 1)
			{
				if (expected == 1)
				{
					A[i]++;
				}
				else if (expected == 0)
				{
					B[i]++;
				}
			}
			else if (predicted == 0)
			{
				if (expected == 1)
				{
					C[i]++;
				}
				else if (expected == 0)
				{
					D[i]++;
				}
			}
		}
	}


	for (int i = 0; i < output.front().size(); i++)
	{
		Overall_accuracy[i] = (A[i] + D[i]) / (A[i] + B[i] + C[i] + D[i]);
		Precision[i] = A[i] / (A[i] + B[i]);
		Recall[i] = A[i] / (A[i] + C[i]);
		F1[i] = (2 * Precision[i] * Recall[i]) / (Precision[i] + Recall[i]);
	}

	double mcA = 0, mcB = 0, mcC = 0, mcD = 0, mcOverall_accuracy = 0, mcPrecision = 0, mcRecall = 0, mcF1 = 0;

	for (int i = 0; i < output.front().size(); i++)
	{
		mcA += A[i];
		mcB += B[i];
		mcC += C[i];
		mcD += D[i];
	}

	mcOverall_accuracy = (mcA + mcD) / (mcA + mcB + mcC + mcD);
	mcPrecision = mcA / (mcA + mcB);
	mcRecall = mcA / (mcA + mcC);
	mcF1 = (2 * mcPrecision * mcRecall) / (mcPrecision + mcRecall);



	double maA = 0, maB = 0, maC = 0, maD = 0, maOverall_accuracy = 0, maPrecision = 0, maRecall = 0, maF1 = 0;

	for (int i = 0; i < output.front().size(); i++)
	{
		maOverall_accuracy += Overall_accuracy[i];
		maPrecision += Precision[i];
		maRecall += Recall[i];
	}

	maOverall_accuracy = maOverall_accuracy / output.front().size();
	maPrecision = maPrecision / output.front().size();
	maRecall = maRecall / output.front().size();
	maF1 = (2 * maPrecision * maRecall) / (maPrecision + maRecall);


	cout << endl << endl;
	ry();
	cout << "Metrics : ";
	bw();
	cout << endl << endl;
	for (int i = 0; i < output.front().size(); i++)
	{
		if (output.front().size() == 1)
		{
			cout << "Output :" << endl;
		}
		else
		{
			cout << "Output " << i << " :" << endl;
		}
		cout << "A : " << A[i] << endl;
		cout << "B : " << B[i] << endl;
		cout << "C : " << C[i] << endl;
		cout << "D : " << D[i] << endl;
		cout << fixed << setprecision(3);
		cout << "Overall Accuracy : " << Overall_accuracy[i] << endl;
		cout << "Precision : " << Precision[i] << endl;
		cout << "Recall : " << Recall[i] << endl;
		cout << "F1 : " << F1[i] << endl;
		cout << defaultfloat;
		cout << endl;
	}

	cout << fixed << setprecision(3);

	cout << "Micro-Averaged Metrics : " << endl;
	cout << "mcOverall Accuracy : " << mcOverall_accuracy << endl;
	cout << "mcPrecision : " << mcPrecision << endl;
	cout << "mcRecall : " << mcRecall << endl;
	cout << "mcF1 : " << mcF1 << endl;

	cout << endl << "Macro-Averaged Metrics : " << endl;
	cout << "maOverall Accuracy : " << maOverall_accuracy << endl;
	cout << "maPrecision : " << maPrecision << endl;
	cout << "maRecall : " << maRecall << endl;
	cout << "maF1 : " << maF1 << endl;



	ofstream myfile(nn_file_name);
	if (myfile.is_open())
	{
		myfile << trained_nn->Ni << " " << trained_nn->Nh << " " << trained_nn->No << "\n";
		myfile << fixed << setprecision(3);
		for (int i = 0; i < trained_nn->Nh; i++)
		{
			for (int j = 0; j < trained_nn->Ni + 1; j++)
			{
				if (j == 0)
				{
					myfile << trained_nn->hidden_layer[i]->input_weights[j] << " ";
				}
				else
				{
					myfile << trained_nn->hidden_layer[i]->input_weights[j] << " ";
				}
			}

			// Newline for new row

			myfile << endl;
		}


		for (int i = 0; i < trained_nn->No; i++)
		{
			for (int j = 0; j < trained_nn->Nh + 1; j++)
			{
				if (j == 0)
				{
					myfile << trained_nn->output_layer[i]->input_weights[j] << " ";
				}
				else
				{
					myfile << trained_nn->output_layer[i]->input_weights[j] << " ";
				}
			}

			// Newline for new row

			myfile << endl;
		}

		myfile << defaultfloat;
		myfile.close();
	}
	else cout << "Unable to open file";




	ofstream res_myfile(res_file_name);
	if (res_myfile.is_open())
	{
		res_myfile << fixed << setprecision(3);
		for (int i = 0; i < output.front().size(); i++)
		{
			res_myfile << defaultfloat;
			res_myfile << A[i] << " " << B[i] << " " << C[i] << " " << D[i] << " ";
			res_myfile << fixed << setprecision(3);
			res_myfile << Overall_accuracy[i] << " " << Precision[i] << " " << Recall[i] << " " << F1[i] << endl;
			res_myfile << defaultfloat;
		}

		res_myfile << fixed << setprecision(3);
		res_myfile << mcOverall_accuracy << " " << mcPrecision << " " << mcRecall << " " << mcF1 << endl;
		res_myfile << maOverall_accuracy << " " << maPrecision << " " << maRecall << " " << maF1;
		res_myfile << defaultfloat;
		res_myfile.close();
	}
	else cout << "Unable to open file";



	cout << defaultfloat;
	return 0;
}
