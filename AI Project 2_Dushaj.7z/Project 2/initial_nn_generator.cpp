#include<vector>
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;


int main()
{
	// ((double)rand() / (RAND_MAX)) generates a random number between 0 and 1

	// Inputs for creating the neural net
	int Ni = 4; // number of inputs
	int Nh = 10; // number of hidden layer nodes
	int No = 3; // number of output layer nodes

	string nn_file_name = "initial_nn.txt";
	ofstream myfile(nn_file_name);
	if (myfile.is_open())
	{
		myfile << Ni << " " << Nh << " " << No << "\n";
		myfile << fixed << setprecision(3);
		for (int i = 0; i < Nh; i++)
		{
			for (int j = 0; j < Ni + 1; j++)
			{
				if (j == 0)
				{
					myfile << ((double)rand() / (RAND_MAX)) << " ";
				}
				else
				{
					myfile << ((double)rand() / (RAND_MAX)) << " ";
				}
			}

			// Newline for new row

			myfile << endl;
		}


		for (int i = 0; i < No; i++)
		{
			for (int j = 0; j < Nh + 1; j++)
			{
				if (j == 0)
				{
					myfile << ((double)rand() / (RAND_MAX)) << " ";
				}
				else
				{
					myfile << ((double)rand() / (RAND_MAX)) << " ";
				}
			}

			// Newline for new row

			myfile << endl;
		}

		myfile << defaultfloat;
		myfile.close();
	}
	else cout << "Unable to open file";

}

